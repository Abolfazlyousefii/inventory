<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('products', function (Blueprint $table) {
        $table->id();
        $table->foreignId('category_id')->constrained()->cascadeOnDelete();

        $table->string('name');
        $table->string('sku')->unique();              // شناسه محصول
        $table->unsignedInteger('stock')->default(0); // موجودی
        $table->unsignedBigInteger('price');          // قیمت (تومان/ریال) عدد صحیح

        $table->timestamps();
    });
}


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
